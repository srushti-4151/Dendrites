import React from 'react';

function newhome(props) {
    return (
        <div>
            <h1>Home NeW PAGe</h1>
        </div>
    );
}

export default newhome;
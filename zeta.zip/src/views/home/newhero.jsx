import React from 'react';

function newhero(props) {
    return (
        <div>
            <h1>Hello</h1>
        </div>
    );
}

export default newhero;